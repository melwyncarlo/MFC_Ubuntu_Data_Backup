#!/bin/bash


create_mfcdb_launcher()
{
	icon_extra=("" "l")
	name_extra=("" " Lite")
	exec_extra=("" "litestart")
	comment_extra=("Original" "Lite")
	keyword_extra=("" "Lite;")

	for ((i = 0; i < 2; i++))
	do
		launcherString="#!/usr/bin/env xdg-open\n[Desktop Entry]\n"
		launcherString+="Version=1.0\nType=Application\nTerminal=true\n"
		launcherString+="Icon[en_GB]=/home/`whoami`/mfcubuntudatabackup/images/mfcdb${icon_extra[$i]}.png\n"
		launcherString+="Icon=/home/`whoami`/mfcubuntudatabackup/images/mfcdb${icon_extra[$i]}.png\n"
		launcherString+="Name[en_GB]=MFC Backup${name_extra[$i]}\nName=MFC Backup${name_extra[$i]}\n"
		launcherString+="Exec=/home/`whoami`/mfcubuntudatabackup/databackup${exec_extra[$i]}.sh\n"
		launcherString+="Comment[en_GB]=This is the ${comment_extra[$i]} version of the MFC Data Backup App\n"
		launcherString+="Comment=This is the ${comment_extra[$i]} version of the MFC Data Backup App\n"
		launcherString+="Keywords=MFC;Backup;${keyword_extra[$i]}"
		echo -e "$launcherString" | sudo tee "/usr/share/applications/mfcdb${icon_extra[$i]}.desktop"
	done
}


create_mfcdb_links()
{
	filepathString01="/home/`whoami`/Desktop/MFC-Ubuntu-Backup-Userbase"
	filepathString02="/home/`whoami`/mfcubuntudatabackup/data"

	mkdir "$filepathString01"
	mkdir "$filepathString01/Transfer-Logs"
	mkdir "$filepathString01/Transfer-Logs/MFC-Backup"
	mkdir "$filepathString01/Transfer-Logs/MFC-Backup-Lite"
	mkdir "$filepathString01/App-Parameters"

	ln -fs "$filepathString02/db.log" \
	"$filepathString01/Transfer-Logs/MFC-Backup/Log"
	ln -fs "$filepathString02/dblite.log" \
	"$filepathString01/Transfer-Logs/MFC-Backup-Lite/Log-1"
	ln -fs "$filepathString02/dblitetransfer.log" \
	"$filepathString01/Transfer-Logs/MFC-Backup-Lite/Log-2"

	ln -fs "$filepathString02/dbthreadsopt" \
	"$filepathString01/App-Parameters/Number-of-Processors"
	ln -fs "$filepathString02/paths_list.dat" \
	"$filepathString01/App-Parameters/List-of-Backup-Paths"
	ln -fs "$filepathString02/dbcompresslevel" \
	"$filepathString01/App-Parameters/Compression-Level"
	ln -fs "$filepathString02/dbliteargs" \
	"$filepathString01/App-Parameters/MFC-DB-Lite-Arguments"
}


if [[ "`pwd`" != "/home/`whoami`/Downloads/mfcubuntudatabackup_container" ]]; then
	messageString="\n\n\n Unable to install as the application directory is\n"
	messageString+=" not located in the system's 'Downloads' directory !\n\n"
	messageString+=" Please download and extract the application in the\n"
	messageString+=" system's 'Downloads' directory itself.\n\n\n"
	echo -e "$messageString"
else
	clear
	clear
	messageString="\n\n#############################################################################\n\n"
	messageString+=" MFC Ubuntu Data Backup v1.0\n\nInstalling . . .\n\n"
	messageString+="#############################################################################\n\n\n"
	echo -e "$messageString"
	sleep 1.5

	cp -rfv "/home/`whoami`/Downloads/mfcubuntudatabackup_container/mfcubuntudatabackup" "/home/`whoami`"
	mkdir "/home/`whoami`/mfcubuntudatabackup/zpaq715"
	unzip "/home/`whoami`/mfcubuntudatabackup/zpaq715.zip" -d "/home/`whoami`/mfcubuntudatabackup/zpaq715"
	cd "/home/`whoami`/mfcubuntudatabackup/zpaq715" && make
	rm -rfv "/home/`whoami`/mfcubuntudatabackup/zpaq715.zip"
	rm -rfv "/home/`whoami`/Downloads/mfcubuntudatabackup.tar"
	create_mfcdb_launcher
	create_mfcdb_links
	{ sleep 2; cd "/home/`whoami`"; rm -rf "/home/`whoami`/Downloads/mfcubuntudatabackup_container"; } &
	disown

	messageString="\n\n\n#############################################################################\n\n"
	messageString+=" Installation Complete !\n\n"
	messageString+="#############################################################################\n\n\n\n"
	echo -e "$messageString"
fi



